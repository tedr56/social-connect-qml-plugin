#include <QtGui/QApplication>
#include "qmlapplicationviewer.h"

// socialconnect additions begin

#include "socialconnectplugin.h"

// socialconnect additions end

Q_DECL_EXPORT int main(int argc, char *argv[])
{
    QScopedPointer<QApplication> app(createApplication(argc, argv));

    // socialconnect additions begin

    SocialConnectPlugin plugin;
    plugin.registerTypes("SocialConnect");

    // socialconnect additions end

    QmlApplicationViewer viewer;
    viewer.setOrientation(QmlApplicationViewer::ScreenOrientationAuto);
    viewer.setMainQmlFile(QLatin1String("qml/socialapp/main.qml"));
    viewer.showExpanded();

    return app->exec();
}
